# CIX experimental source reproduction

This is a local source-release candidate, not an official leaderboard entry.
Python 3.12, a C++17 compiler, CMake and an AVX2-capable Linux x86-64 system were
used for qualification. Install requirements-research.txt into a virtual
environment, then run from this directory:

    python -m benchmarks.reproduce_build --build-only --jobs 3
    python -m benchmarks.competitive_cli encode input.bin output.cix
    python -m benchmarks.competitive_cli decode output.cix restored.bin
    cmp input.bin restored.bin

The build script performs no network or CI operations. Input/output paths must
be distinct, and the codec refuses existing destinations. Encoding may be slow:
it tries the whole portfolio and independently verifies its selected stream.

PAQ8px v215/v216 source, original copyright/license notices, upstream revision
and archive hashes are included. The documented v216 include-case correction
is applied. Bundled zlib retains its own notices. NumPy, imagecodecs (including
JPEG XL/JPEG-LS/JPEG 2000), Brotli and Zstandard remain external dependencies;
their licenses and notices apply. CIX is research source; no new license grant
or official submission is implied by this staging operation.

The isolated PAQ stored-state decoder source and provenance are included. Its
level-zero repair provides decoder state without probability models. Native
reference backends remain unmodified; the extra fork is built separately.

SOURCE-MANIFEST.json records every staged file hash and the CIX source revision.
BUILD-RESULT.json records local rebuilt binary hashes. Benchmark corpora and
saved compressed outputs are deliberately absent. See
docs/research/competitive-reproduction.md for measurement and cache discipline.
